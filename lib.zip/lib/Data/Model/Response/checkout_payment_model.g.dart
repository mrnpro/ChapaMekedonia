// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'checkout_payment_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CheckoutPaymentModel _$CheckoutPaymentModelFromJson(
        Map<String, dynamic> json) =>
    CheckoutPaymentModel(
      json['checkout_url'] as String,
    );

Map<String, dynamic> _$CheckoutPaymentModelToJson(
        CheckoutPaymentModel instance) =>
    <String, dynamic>{
      'checkout_url': instance.checkout_url,
    };
