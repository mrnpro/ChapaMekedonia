class APIs {
  APIs._();

  static String get initializeChapa => "/v1/transaction/initialize/";
  static String get chapaVerirfication => "/v1/transaction/verify/";
}
