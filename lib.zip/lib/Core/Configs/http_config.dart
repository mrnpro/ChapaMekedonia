class HttpConfig {
  HttpConfig._();

  static String get chapaBaseUrl => "https://api.chapa.co";
  static String get chapaAPIKey =>
      "CHASECK_TEST-cSEhoLNUwfTbM1dExMYKXrcg1yEJa9a5";
}
